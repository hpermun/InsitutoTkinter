# Vista para matricular un alumno en una o varias asignaturas
import tkinter as tk
from tkinter import messagebox
from controlador import matricula_asignatura_controlador as controlador

# Ventana para seleccionar asignaturas y matricular a un alumno
class MatriculaAsignaturaView(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Matricular Alumno en Asignaturas")
        self.geometry("500x450")
        self.configure(bg="white")
        self.resizable(False, False)

        # Entrada para ID del alumno
        tk.Label(self, text="ID del Alumno:", font=("Segoe UI", 12), bg="white").pack(pady=10)
        self.entry_id = tk.Entry(self, font=("Segoe UI", 12))
        self.entry_id.pack(pady=5)

        # Lista de asignaturas disponibles
        tk.Label(self, text="Asignaturas Disponibles:", font=("Segoe UI", 12), bg="white").pack(pady=10)
        self.lista = tk.Listbox(self, selectmode=tk.MULTIPLE, width=50, height=15)
        self.lista.pack(pady=5)

        # Botón para realizar la matrícula
        self.btn_matricular = tk.Button(self, text="Matricular", command=self.matricular, bg="#4CAF50", fg="white", font=("Segoe UI", 12))
        self.btn_matricular.pack(pady=20)

        # Cargar las asignaturas desde el controlador
        self.asignaturas = controlador.obtener_asignaturas()
        for asignatura in self.asignaturas:
            self.lista.insert(tk.END, f"{asignatura[0]} - {asignatura[1]}")

    # Matricula al alumno seleccionado en las asignaturas elegidas
    def matricular(self):
        alumno_id = self.entry_id.get()
        if not alumno_id.isdigit():
            messagebox.showerror("Error", "El ID del alumno debe ser un número entero.")
            return
        alumno_id = int(alumno_id)

        seleccion = self.lista.curselection()
        if not seleccion:
            if not messagebox.askyesno("Confirmar", "No has seleccionado ninguna asignatura. ¿Deseas continuar?"):
                return

        asignaturas_ids = [self.asignaturas[i][0] for i in seleccion]
        errores = controlador.matricular_alumno(alumno_id, asignaturas_ids)

        if errores:
            messagebox.showwarning("Atención", f"Algunas asignaturas ya estaban matriculadas: {errores}")
        else:
            messagebox.showinfo("Éxito", "Alumno matriculado correctamente.")

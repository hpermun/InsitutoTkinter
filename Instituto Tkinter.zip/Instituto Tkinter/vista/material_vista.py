# Vista para gestionar materiales: agregar, eliminar y visualizar
import tkinter as tk
from tkinter import ttk, messagebox
from controlador.material_controlador import MaterialController

# Ventana para administrar los materiales del instituto
class MaterialView(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title('Gestión de Materiales')
        self.geometry("600x400")
        self.configure(bg="#f4f4f4")
        self.ctrl = MaterialController()
        self.selected_id = None

        fuente = ("Segoe UI", 11)

        # --- Formulario para ingresar datos del material ---
        form_frame = tk.Frame(self, bg="#f4f4f4")
        form_frame.pack(pady=10)

        tk.Label(form_frame, text='Nombre', bg="#f4f4f4", font=fuente).grid(row=0, column=0, padx=5, pady=5, sticky="e")
        self.e_nombre = tk.Entry(form_frame, font=fuente, width=30)
        self.e_nombre.grid(row=0, column=1, padx=5)

        tk.Label(form_frame, text='Descripción', bg="#f4f4f4", font=fuente).grid(row=1, column=0, padx=5, pady=5, sticky="e")
        self.e_desc = tk.Entry(form_frame, font=fuente, width=30)
        self.e_desc.grid(row=1, column=1, padx=5)

        # --- Botones de acción ---
        btn_frame = tk.Frame(self, bg="#f4f4f4")
        btn_frame.pack(pady=10)

        tk.Button(btn_frame, text='Agregar', width=15, bg="#2c2c2c", fg="white", font=fuente, command=self._guardar).grid(row=0, column=0, padx=10)
        tk.Button(btn_frame, text='Eliminar', width=15, bg="#990000", fg="white", font=fuente, command=self._eliminar).grid(row=0, column=1, padx=10)

        # --- Tabla de materiales ---
        self.tree = ttk.Treeview(self, columns=('id', 'nombre', 'descripcion'), show='headings', height=10)
        self.tree.heading('id', text='ID')
        self.tree.heading('nombre', text='Nombre')
        self.tree.heading('descripcion', text='Descripción')
        self.tree.column('id', width=0, stretch=False)  # Ocultamos la columna ID
        self.tree.column('nombre', width=200)
        self.tree.column('descripcion', width=300)

        self.tree.pack(padx=10, pady=10, fill="both", expand=True)
        self.tree.bind('<<TreeviewSelect>>', self._on_select)

        # Cargar los datos al iniciar la ventana
        self._cargar()

    # Guarda un nuevo material
    def _guardar(self):
        nombre = self.e_nombre.get().strip()
        descripcion = self.e_desc.get().strip()

        if not nombre:
            messagebox.showwarning("Campo requerido", "El nombre es obligatorio.")
            return

        data = {'nombre': nombre, 'descripcion': descripcion}
        self.ctrl.add(data)
        self._limpiar()
        self._cargar()

    # Elimina el material seleccionado
    def _eliminar(self):
        if self.selected_id is None:
            messagebox.showwarning("Selecciona un material", "Debes seleccionar un material para eliminarlo.")
            return

        confirmar = messagebox.askyesno("Confirmar", "¿Estás seguro de eliminar este material?")
        if confirmar:
            self.ctrl.delete(self.selected_id)
            self._limpiar()
            self._cargar()
            messagebox.showinfo("Eliminado", "Material eliminado correctamente.")

    # Carga el material seleccionado en el formulario
    def _on_select(self, event):
        selected_item = self.tree.selection()
        if selected_item:
            item = selected_item[0]
            vals = self.tree.item(item)['values']
            self.selected_id = vals[0]
            self.e_nombre.delete(0, tk.END)
            self.e_nombre.insert(0, vals[1])
            self.e_desc.delete(0, tk.END)
            self.e_desc.insert(0, vals[2])

    # Limpia los campos del formulario
    def _limpiar(self):
        self.e_nombre.delete(0, tk.END)
        self.e_desc.delete(0, tk.END)
        self.selected_id = None

    # Carga todos los materiales en la tabla
    def _cargar(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for m in self.ctrl.list():
            self.tree.insert('', 'end', values=(m.id, m.nombre, m.descripcion))

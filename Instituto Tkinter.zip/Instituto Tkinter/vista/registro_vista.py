# Vista de registro de administradores (ventana independiente)
import tkinter as tk
from tkinter import messagebox
from db import Database

# Clase que representa la ventana de registro de usuario administrador
class RegistroView(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Registro Administrador')
        
        # Etiquetas y campos de entrada para usuario y contraseña
        tk.Label(self, text='Usuario').grid(row=0, column=0)
        tk.Label(self, text='Contraseña').grid(row=1, column=0)
        self.u = tk.Entry(self);   self.u.grid(row=0, column=1)
        self.p = tk.Entry(self, show='*'); self.p.grid(row=1, column=1)

        # Botón para registrar el usuario
        tk.Button(self, text='Registrar', command=self._registrar).grid(row=2, column=0, columnspan=2)

    # Método que maneja el registro de un nuevo usuario
    def _registrar(self):
        user = self.u.get().strip()
        pwd  = self.p.get().strip()
        if not user or not pwd:
            messagebox.showerror('Error', 'Debes rellenar ambos campos')
            return
        db = Database()
        try:
            # Inserta el nuevo usuario en la base de datos
            db.execute('INSERT INTO usuario (username, password) VALUES (?, ?)', (user, pwd))
            messagebox.showinfo('OK', 'Usuario registrado correctamente')
            self.destroy()
        except Exception as e:
            # Muestra un error si el registro falla
            messagebox.showerror('Error', f'No se pudo registrar:\n{e}')

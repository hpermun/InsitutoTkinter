# Vista para la gestión de miembros de dirección del instituto
import tkinter as tk
from tkinter import ttk, messagebox
from controlador.persona_controlador import PersonaController

# Ventana para gestionar datos de personas con rol directivo
class DireccionView(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title('Gestión Dirección')
        self.geometry("500x400")
        self.ctrl = PersonaController()

        # --- Formulario para ingresar datos ---
        tk.Label(self, text='Nombre').grid(row=0, column=0, padx=5, pady=5)
        self.nombre = tk.Entry(self); self.nombre.grid(row=0, column=1, padx=5)

        tk.Label(self, text='Apellidos').grid(row=1, column=0, padx=5, pady=5)
        self.apellidos = tk.Entry(self); self.apellidos.grid(row=1, column=1, padx=5)

        tk.Label(self, text='Fecha Nac. (YYYY-MM-DD)').grid(row=2, column=0, padx=5, pady=5)
        self.fnac = tk.Entry(self); self.fnac.grid(row=2, column=1, padx=5)

        tk.Label(self, text='Rol').grid(row=3, column=0, padx=5, pady=5)
        self.rol = tk.Entry(self); self.rol.grid(row=3, column=1, padx=5)

        # --- Botones de acción ---
        tk.Button(self, text='Guardar', command=self._guardar).grid(row=4, column=0, padx=5, pady=10)
        tk.Button(self, text='Eliminar', command=self._eliminar).grid(row=4, column=1, padx=5, pady=10)

        # --- Tabla para mostrar miembros registrados ---
        cols = ('id', 'nombre', 'apellidos', 'fecha_nacimiento', 'rol')
        self.tree = ttk.Treeview(self, columns=cols, show='headings', height=10)
        for c in cols:
            self.tree.heading(c, text=c.title())
            self.tree.column(c, width=100)
        self.tree.grid(row=5, column=0, columnspan=2, padx=10, pady=10)
        self.tree.bind('<<TreeviewSelect>>', self._on_select)

        self.selected = None
        self._cargar_tabla()

    # Carga los datos de los miembros de dirección en la tabla
    def _cargar_tabla(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for miembro in self.ctrl.list_direccion():
            self.tree.insert('', 'end', values=(
                miembro.id, miembro.nombre, miembro.apellidos,
                miembro.fecha_nacimiento, miembro.rol
            ))

    # Guarda o actualiza los datos de un miembro
    def _guardar(self):
        data = {
            'nombre': self.nombre.get(),
            'apellidos': self.apellidos.get(),
            'fecha_nacimiento': self.fnac.get(),
            'rol': self.rol.get()
        }

        if not data['nombre'] or not data['apellidos'] or not data['rol']:
            messagebox.showwarning("Campos requeridos", "Nombre, Apellidos y Rol son obligatorios.")
            return

        if self.selected:
            self.ctrl.update_direccion(self.selected, data)
            messagebox.showinfo("Actualizado", "Miembro actualizado correctamente.")
        else:
            self.ctrl.add_direccion(data)
            messagebox.showinfo("Guardado", "Miembro guardado correctamente.")

        self._limpiar_campos()
        self._cargar_tabla()

    # Elimina el miembro seleccionado
    def _eliminar(self):
        if not self.selected:
            messagebox.showwarning("Selección requerida", "Selecciona un miembro para eliminar.")
            return

        confirmar = messagebox.askyesno("Confirmar eliminación", "¿Estás seguro de eliminar este miembro?")
        if confirmar:
            self.ctrl.delete_direccion(self.selected)
            self._limpiar_campos()
            self._cargar_tabla()
            messagebox.showinfo("Eliminado", "Miembro eliminado correctamente.")
            self.selected = None

    # Carga los datos seleccionados desde la tabla al formulario
    def _on_select(self, event):
        selected_item = self.tree.selection()
        if selected_item:
            item = selected_item[0]
            vals = self.tree.item(item)['values']
            self.nombre.delete(0, tk.END); self.nombre.insert(0, vals[1])
            self.apellidos.delete(0, tk.END); self.apellidos.insert(0, vals[2])
            self.fnac.delete(0, tk.END); self.fnac.insert(0, vals[3])
            self.rol.delete(0, tk.END); self.rol.insert(0, vals[4])

            for miembro in self.ctrl.list_direccion():
                if miembro.id == vals[0]:
                    self.selected = miembro
                    break

    # Limpia los campos del formulario
    def _limpiar_campos(self):
        self.nombre.delete(0, tk.END)
        self.apellidos.delete(0, tk.END)
        self.fnac.delete(0, tk.END)
        self.rol.delete(0, tk.END)
        self.selected = None

# Ventana para gestionar asignaturas (crear, actualizar, eliminar)
import tkinter as tk
from tkinter import ttk, messagebox
from controlador.asignatura_controlador import AsignaturaController

class AsignaturaView(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title('Gestión de Asignaturas')
        self.geometry("600x450")
        self.configure(bg="#f4f4f4")
        self.resizable(False, False)

        self.ctrl = AsignaturaController()
        self.selected = None

        fuente = ("Segoe UI", 11)

        # --- Formulario para crear/modificar asignaturas ---
        form = tk.Frame(self, bg="#f4f4f4")
        form.pack(pady=10)

        tk.Label(form, text='Nombre:', bg="#f4f4f4", font=fuente).grid(row=0, column=0, padx=10, pady=5, sticky="e")
        self.e_nombre = tk.Entry(form, font=fuente, width=30)
        self.e_nombre.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(form, text='Departamento:', bg="#f4f4f4", font=fuente).grid(row=1, column=0, padx=10, pady=5, sticky="e")
        self.e_depto = tk.Entry(form, font=fuente, width=30)
        self.e_depto.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(form, text='ID Profesor:', bg="#f4f4f4", font=fuente).grid(row=2, column=0, padx=10, pady=5, sticky="e")
        self.e_profesor = tk.Entry(form, font=fuente, width=30)
        self.e_profesor.grid(row=2, column=1, padx=10, pady=5)

        # --- Botones de acción ---
        botones = tk.Frame(self, bg="#f4f4f4")
        botones.pack(pady=10)

        tk.Button(botones, text='Guardar', bg="#2c2c2c", fg="white", font=fuente, command=self._guardar).grid(row=0, column=0, padx=10)
        tk.Button(botones, text='Eliminar', bg="#8b0000", fg="white", font=fuente, command=self._eliminar).grid(row=0, column=1, padx=10)

        # --- Tabla para mostrar asignaturas ---
        cols = ('id', 'nombre', 'departamento', 'profesor_id', 'profesor')
        self.tree = ttk.Treeview(self, columns=cols, show='headings', height=10)
        for col in cols:
            self.tree.heading(col, text=col.capitalize())
            self.tree.column(col, width=120)
        self.tree.pack(padx=10, pady=10, fill='both', expand=True)
        self.tree.bind('<<TreeviewSelect>>', self._on_select)

        self._cargar()

    # Guarda o actualiza la asignatura ingresada
    def _guardar(self):
        nombre = self.e_nombre.get()
        departamento = self.e_depto.get()
        profesor_id = self.e_profesor.get()

        if not nombre or not profesor_id.isdigit():
            messagebox.showwarning("Campo requerido", "El nombre y el ID del profesor son obligatorios.")
            return

        data = {
            'nombre': nombre,
            'departamento': departamento,
            'profesor_id': int(profesor_id)
        }

        try:
            if self.selected:
                self.ctrl.update(self.selected, data)
                messagebox.showinfo("Actualizado", "Asignatura actualizada correctamente.")
            else:
                self.ctrl.add(data)
                messagebox.showinfo("Guardado", "Asignatura guardada correctamente.")
        except ValueError as e:
            messagebox.showerror("Error", str(e))

        self._limpiar()
        self._cargar()

    # Elimina la asignatura seleccionada
    def _eliminar(self):
        if not self.selected:
            messagebox.showwarning("Selección requerida", "Selecciona una asignatura para eliminar.")
            return

        confirmar = messagebox.askyesno("Confirmar", "¿Seguro que deseas eliminar esta asignatura?")
        if confirmar:
            self.ctrl.delete(self.selected)
            self._limpiar()
            self._cargar()
            messagebox.showinfo("Eliminado", "Asignatura eliminada correctamente.")
            self.selected = None

    # Carga los datos de la fila seleccionada al formulario
    def _on_select(self, event):
        selected_item = self.tree.selection()
        if selected_item:
            item = selected_item[0]
            vals = self.tree.item(item)['values']
            self.selected = vals[0]
            self.e_nombre.delete(0, tk.END); self.e_nombre.insert(0, vals[1])
            self.e_depto.delete(0, tk.END); self.e_depto.insert(0, vals[2])
            self.e_profesor.delete(0, tk.END); self.e_profesor.insert(0, vals[3])

    # Limpia los campos del formulario
    def _limpiar(self):
        self.e_nombre.delete(0, tk.END)
        self.e_depto.delete(0, tk.END)
        self.e_profesor.delete(0, tk.END)
        self.selected = None

    # Carga las asignaturas en la tabla
    def _cargar(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        for a in self.ctrl.list():
            prof = self.ctrl.get_profesor(a.profesor_id)
            prof_info = f"{prof.nombre} {prof.apellidos}" if prof else "Desconocido"
            self.tree.insert('', 'end', values=(a.id, a.nombre, a.departamento, a.profesor_id, prof_info))

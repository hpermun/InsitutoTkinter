# Vista principal para gestionar calificaciones: ver, registrar, editar y exportar
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from controlador.persona_controlador import PersonaController
from controlador.convocatoria_controlador import ConvocatoriaController
from controlador.clase_controlador import ClaseController
from modelo.asignatura import Asignatura
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
import os

# Clase principal para la gestión de calificaciones
class CalificacionesView(tk.Toplevel):
    def __init__(self, master=None, año=None, rol=None):
        super().__init__(master)
        self.title("Gestión de Calificaciones")
        self.geometry("800x750")
        self.ctrl_persona = PersonaController()
        self.ctrl_conv = ConvocatoriaController()
        self.ctrl_clase = ClaseController()
        self.año = año
        self.rol = rol.lower() if rol else "usuario"

        self.alumnos = self.ctrl_persona.list_alumnos()
        self.filtrados = self.alumnos.copy()

        # --- Buscador de alumnos ---
        tk.Label(self, text="Buscar alumno por nombre:", font=("Helvetica", 10)).pack(pady=(10, 0))
        self.entry_buscar = tk.Entry(self)
        self.entry_buscar.pack(pady=5, padx=20, fill='x')
        self.entry_buscar.bind("<KeyRelease>", self._filtrar_alumnos)

        # --- Lista de alumnos ---
        tk.Label(self, text="Selecciona un alumno", font=("Helvetica", 12, "bold")).pack(pady=(10, 0))
        self.lista = tk.Listbox(self, font=("Helvetica", 10), height=10)
        self.lista.pack(pady=5, fill='x', padx=20)
        self.lista.bind("<<ListboxSelect>>", self._mostrar_notas)
        self._actualizar_lista_alumnos()

        # --- Tabla de notas por asignatura ---
        self.tree = ttk.Treeview(self, columns=("asignatura", "tipo", "nota", "fecha"), show='headings', height=10)
        self.tree.heading("asignatura", text="Asignatura")
        self.tree.heading("tipo", text="Evaluación")
        self.tree.heading("nota", text="Nota")
        self.tree.heading("fecha", text="Fecha")
        self.tree.column("asignatura", width=220)
        self.tree.column("tipo", width=130)
        self.tree.column("nota", width=80)
        self.tree.column("fecha", width=120)
        self.tree.pack(pady=10, padx=20, fill='both', expand=True)

        # Etiqueta para mostrar nota media
        self.media_label = tk.Label(self, text="Nota media: -", font=("Helvetica", 12))
        self.media_label.pack(pady=10)

        # --- Botones adicionales (solo para profesores o admins) ---
        if self.rol in ["profesor", "administrador"]:
            boton_frame = tk.Frame(self)
            boton_frame.pack(pady=(15, 20))

            # Botón para registrar nueva calificación
            btn_registrar = tk.Button(
                boton_frame,
                text="➕ Registrar Nota",
                command=self._abrir_registro,
                font=("Helvetica", 10, "bold"),
                bg="black",
                fg="white",
                padx=15,
                pady=6,
                relief="flat",
                cursor="hand2"
            )
            btn_registrar.pack(side="left", padx=10)

            # Botón para exportar todo el historial en PDF
            btn_exportar = tk.Button(
                boton_frame,
                text="📄 Exportar Todas en PDF",
                command=self._exportar_todas,
                font=("Helvetica", 10, "bold"),
                bg="black",
                fg="white",
                padx=15,
                pady=6,
                relief="flat",
                cursor="hand2"
            )
            btn_exportar.pack(side="left", padx=10)

            # Doble clic para editar nota
            self.tree.bind("<Double-1>", self._editar_nota)

            # Exportar solo por materia
            btn_exportar_materia = tk.Button(
                boton_frame,
                text="📄 Exportar por Materia",
                command=self._exportar_por_materia,
                font=("Helvetica", 10, "bold"),
                bg="black",
                fg="white",
                padx=15,
                pady=6,
                relief="flat",
                cursor="hand2"
            )
            btn_exportar_materia.pack(side="left", padx=10)

    # Actualiza la lista de alumnos mostrados
    def _actualizar_lista_alumnos(self):
        self.lista.delete(0, tk.END)
        for a in self.filtrados:
            self.lista.insert(tk.END, f"{a.id} - {a.nombre} {a.apellidos}")

    # Filtro en vivo por nombre
    def _filtrar_alumnos(self, event=None):
        filtro = self.entry_buscar.get().lower()
        self.filtrados = [a for a in self.alumnos if filtro in f"{a.nombre} {a.apellidos}".lower()]
        self._actualizar_lista_alumnos()

    # Muestra las notas del alumno seleccionado
    def _mostrar_notas(self, event=None):
        seleccion = self.lista.curselection()
        if not seleccion:
            return
        idx = seleccion[0]
        self.alumno_seleccionado = self.filtrados[idx]
        self._mostrar_notas_fijas(self.alumno_seleccionado.id)

    # Carga y muestra las calificaciones del alumno
    def _mostrar_notas_fijas(self, alumno_id):
        calificaciones = self.ctrl_conv.list_por_alumno_y_anio(alumno_id, self.año)
        self.tree.delete(*self.tree.get_children())

        self.ultima_nota_por_asignatura = {}
        for fila in calificaciones:
            nombre_asignatura = self._get_nombre_asignatura(fila.clase_id)
            if (nombre_asignatura not in self.ultima_nota_por_asignatura or
                fila.fecha > self.ultima_nota_por_asignatura[nombre_asignatura].fecha):
                self.ultima_nota_por_asignatura[nombre_asignatura] = fila

        total = 0
        count = 0
        for nombre_asignatura, fila in self.ultima_nota_por_asignatura.items():
            self.tree.insert('', 'end', values=(nombre_asignatura, fila.tipo, fila.nota, fila.fecha))
            try:
                total += float(fila.nota)
                count += 1
            except:
                pass

        media = round(total / count, 2) if count > 0 else "-"
        self.media_label.config(text=f"Nota media: {media}")

    # Obtiene el nombre de la asignatura dado el ID de clase
    def _get_nombre_asignatura(self, clase_id):
        clase = self.ctrl_clase.get(clase_id)
        if clase and hasattr(clase, "asignatura_id"):
            asignatura = Asignatura.get_by_id(clase.asignatura_id)
            if asignatura:
                return asignatura.nombre
        return f"Clase {clase_id}"

    # Abre la ventana de registro de nota
    def _abrir_registro(self):
        VentanaRegistrarCalificacion(self)

    # Permite editar una nota haciendo doble clic
    def _editar_nota(self, event):
        item = self.tree.identify_row(event.y)
        if not item:
            return
        values = self.tree.item(item, "values")
        asignatura_nombre = values[0]
        nota_actual = values[1]
        fecha = values[2]
        alumno_id = self.alumno_seleccionado.id

        nueva = simpledialog.askstring("Editar nota", f"Introduce nueva nota para {asignatura_nombre}:", initialvalue=nota_actual)
        if nueva:
            try:
                nota_f = float(nueva)
                if 0 <= nota_f <= 10:
                    clases = self.ctrl_clase.get_asignaturas_matriculadas_por_alumno(alumno_id)
                    clase_id = None
                    for row in clases:
                        asignatura = Asignatura.get_by_id(row["asignatura_id"])
                        if asignatura and asignatura.nombre == asignatura_nombre:
                            clase_id = row["id"]
                            break
                    if clase_id:
                        self.ctrl_conv.actualizar_nota(alumno_id, clase_id, fecha, nota_f)
                        messagebox.showinfo("Guardado", "Nota actualizada correctamente.")
                        self._mostrar_notas_fijas(alumno_id)
                    else:
                        messagebox.showerror("Error", "No se encontró la clase para esta asignatura.")
                else:
                    raise ValueError
            except:
                messagebox.showerror("Error", "Introduce un número entre 0 y 10.")

    # Exporta todas las calificaciones del sistema en PDF
    def _exportar_todas(self):
        filas = self.ctrl_conv.obtener_todas_las_calificaciones()
        if not filas:
            messagebox.showinfo("Sin datos", "No hay calificaciones registradas para este año.")
            return

        ruta = os.path.join(os.getcwd(), f"calificaciones_completas_{self.año}.pdf")
        c = canvas.Canvas(ruta, pagesize=A4)
        ancho, alto = A4

        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, alto - 50, "Instituto - Tkinter")
        c.setFont("Helvetica", 12)
        c.drawString(50, alto - 80, f"Año académico: {self.año}")

        y = alto - 120
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y, "Alumno")
        c.drawString(250, y, "Materia")
        c.drawString(400, y, "Convocatoria")
        c.drawString(500, y, "Nota")
        y -= 20

        c.setFont("Helvetica", 11)
        filas_ordenadas = sorted(filas, key=lambda x: (x['nombre'], x['apellidos'], x['nombre_materia']))
        for f in filas_ordenadas:
            nombre = f["nombre"] + " " + f["apellidos"]
            c.drawString(50, y, nombre)
            c.drawString(250, y, f["nombre_materia"])
            c.drawString(400, y, f["nombre_convocatoria"])
            c.drawString(500, y, str(f["nota"]))
            y -= 20
            if y < 50:
                c.showPage()
                y = alto - 50

        c.save()
        messagebox.showinfo("PDF generado", f"Calificaciones exportadas a {ruta}")

    # Exporta notas por materia con formato de tabla (1ª, 2ª, 3ª, final, media)
    def _exportar_por_materia(self):
        materias = self.ctrl_clase.get_todas_asignaturas_con_nombre()
        opciones = [f"{m['id']} - {m['nombre']}" for m in materias]
        seleccion = simpledialog.askstring("Seleccionar materia", f"Elige ID de materia para exportar:\n\n" + "\n".join(opciones))

        if not seleccion or not seleccion.split(" - ")[0].isdigit():
            return

        materia_id = int(seleccion.split(" - ")[0])
        filas = self.ctrl_conv.obtener_calificaciones_por_materia(materia_id, self.año)

        if not filas:
            messagebox.showinfo("Sin datos", "No hay calificaciones para esa materia.")
            return

        # Reorganización de datos por alumno
        datos = {}
        for f in filas:
            alumno = f"{f['nombre']} {f['apellidos']}"
            tipo = f['nombre_convocatoria'].strip().lower()
            nota = f['nota']
            if alumno not in datos:
                datos[alumno] = {}
            if tipo in ["primera", "segunda", "tercera", "final"] and tipo not in datos[alumno]:
                datos[alumno][tipo] = nota

        for alumno in datos:
            for campo in ["primera", "segunda", "tercera", "final"]:
                if campo not in datos[alumno]:
                    datos[alumno][campo] = "-"
            notas = [datos[alumno][k] for k in ["primera", "segunda", "tercera"] if isinstance(datos[alumno][k], (int, float))]
            datos[alumno]["media"] = round(sum(notas) / len(notas), 2) if notas else "-"

        # Generación del PDF con tabla
        ruta = os.path.join(os.getcwd(), f"calificaciones_materia_{materia_id}_formato_tabla.pdf")
        c = canvas.Canvas(ruta, pagesize=A4)
        ancho, alto = A4
        y = alto - 50

        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, y, "Instituto - Tkinter")
        c.setFont("Helvetica", 12)
        y -= 25
        c.drawString(50, y, f"Año académico: {self.año}")
        y -= 30

        nombre_materia = next((m["nombre"] for m in materias if m["id"] == materia_id), "Materia desconocida")
        c.setFont("Helvetica-Bold", 12)
        c.drawString(50, y, f"Materia: {nombre_materia}")
        y -= 20

        c.drawString(50, y, "Alumno")
        c.drawString(180, y, "1ª")
        c.drawString(230, y, "2ª")
        c.drawString(280, y, "3ª")
        c.drawString(330, y, "Final")
        c.drawString(400, y, "Media")
        y -= 20

        c.setFont("Helvetica", 11)
        for alumno, notas in datos.items():
            c.drawString(50, y, alumno)
            c.drawString(180, y, str(notas["primera"]))
            c.drawString(230, y, str(notas["segunda"]))
            c.drawString(280, y, str(notas["tercera"]))
            c.drawString(330, y, str(notas["final"]))
            c.drawString(400, y, str(notas["media"]))
            y -= 20
            if y < 50:
                c.showPage()
                y = alto - 50

        c.save()
        messagebox.showinfo("PDF generado", f"Calificaciones exportadas a {ruta}")



# Ventana emergente para registrar una calificación manualmente
class VentanaRegistrarCalificacion(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("Registrar Calificación")
        self.geometry("450x420")
        self.master = master
        self.ctrl_conv = ConvocatoriaController()
        self.ctrl_clase = ClaseController()

        fuente_lbl = ("Helvetica", 10)
        fuente_entry = ("Helvetica", 10)

        # --- Campo: ID del alumno ---
        tk.Label(self, text="ID del alumno:", font=fuente_lbl).pack(pady=(10, 0), anchor="w", padx=20)
        self.entrada_id = tk.Entry(self, font=fuente_entry)
        self.entrada_id.pack(fill="x", padx=20, pady=5)

        # --- Botón para buscar asignaturas del alumno ---
        self.btn_buscar = tk.Button(self, text="Buscar asignaturas", command=self._cargar_asignaturas, bg="black", fg="white")
        self.btn_buscar.pack(fill="x", padx=20, pady=(0, 10))

        # --- ComboBox: Asignatura a calificar ---
        tk.Label(self, text="Asignatura:", font=fuente_lbl).pack(pady=(5, 0), anchor="w", padx=20)
        self.combo_asignatura = ttk.Combobox(self, state="readonly")
        self.combo_asignatura.pack(fill="x", padx=20, pady=5)

        # --- ComboBox: Tipo de evaluación (Primera, Segunda, Tercera) ---
        tk.Label(self, text="Tipo de evaluación:", font=fuente_lbl).pack(pady=(5, 0), anchor="w", padx=20)
        self.combo_tipo = ttk.Combobox(self, state="readonly", values=["Primera", "Segunda", "Tercera"])
        self.combo_tipo.pack(fill="x", padx=20, pady=5)
        self.combo_tipo.current(0)

        # --- Campo: Nota (0-10) ---
        tk.Label(self, text="Nota (0-10):", font=fuente_lbl).pack(pady=(5, 0), anchor="w", padx=20)
        self.entrada_nota = tk.Entry(self, font=fuente_entry)
        self.entrada_nota.pack(fill="x", padx=20, pady=5)

        # --- Campo: Fecha ---
        tk.Label(self, text="Fecha (YYYY-MM-DD):", font=fuente_lbl).pack(pady=(5, 0), anchor="w", padx=20)
        self.entrada_fecha = tk.Entry(self, font=fuente_entry)
        self.entrada_fecha.pack(fill="x", padx=20, pady=5)

        # --- Botón para registrar la calificación ---
        self.btn_registrar = tk.Button(self, text="Registrar Nota", command=self._registrar, bg="black", fg="white")
        self.btn_registrar.pack(pady=20, fill="x", padx=20)

    # Carga las asignaturas en las que está matriculado el alumno
    def _cargar_asignaturas(self):
        alumno_id = self.entrada_id.get()
        if not alumno_id.isdigit():
            messagebox.showerror("Error", "ID inválido.")
            return

        rows = self.ctrl_clase.get_asignaturas_matriculadas_por_alumno(int(alumno_id))
        opciones = []
        self.clases = []

        for row in rows:
            asignatura = Asignatura.get_by_id(row["asignatura_id"])
            if asignatura:
                opciones.append(asignatura.nombre)
                self.clases.append((row["id"], asignatura.id))

        if opciones:
            self.combo_asignatura['values'] = opciones
            self.combo_asignatura.current(0)
        else:
            self.combo_asignatura.set("")
            self.combo_asignatura['values'] = []
            messagebox.showinfo("Sin asignaturas", "Este alumno no está matriculado en ninguna asignatura.")

    # Valida los datos y guarda la nota en la base de datos
    def _registrar(self):
        alumno_id = self.entrada_id.get()
        nota = self.entrada_nota.get()
        fecha = self.entrada_fecha.get()
        index = self.combo_asignatura.current()

        if not (alumno_id and nota and fecha and index != -1):
            messagebox.showerror("Error", "Rellena todos los campos.")
            return

        try:
            nota_f = float(nota)
            if nota_f < 0 or nota_f > 10:
                raise ValueError
        except:
            messagebox.showerror("Error", "La nota debe estar entre 0 y 10.")
            return

        clase_id = self.clases[index][0]
        tipo = self.combo_tipo.get()

        self.ctrl_conv.crear(clase_id, tipo, fecha, nota_f, int(alumno_id))
        messagebox.showinfo("Éxito", "Nota registrada correctamente.")

        # Refresca la tabla de notas si se abrió desde la vista principal
        if hasattr(self.master, "_mostrar_notas"):
            self.master._mostrar_notas()

# Ventana para la gestión de alumnos: permite registrar, modificar y eliminar alumnos.
import tkinter as tk
from tkinter import ttk, messagebox
from controlador.persona_controlador import PersonaController

class AlumnoView(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title('Gestión Alumnos')
        self.geometry("700x550")
        self.configure(bg="#f4f4f4")
        self.ctrl = PersonaController()

        # --- Estilos generales ---
        fuente = ("Segoe UI", 10)
        color_fondo = "#f4f4f4"
        color_boton = "#2c2c2c"
        color_boton_texto = "#ffffff"

        # --- Frame del formulario de entrada de datos del alumno ---
        form_frame = tk.Frame(self, bg=color_fondo)
        form_frame.pack(pady=10)

        # --- Campos del formulario ---
        labels = ['Nombre', 'Apellidos', 'Fecha Nac. (YYYY-MM-DD)', 'Calle', 'Ciudad', 'CP']
        entries = []
        for i, text in enumerate(labels):
            tk.Label(form_frame, text=text, font=fuente, bg=color_fondo).grid(row=i, column=0, sticky="w", padx=10, pady=5)
            entry = tk.Entry(form_frame, font=fuente)
            entry.grid(row=i, column=1, padx=10, pady=5)
            entries.append(entry)

        self.nombre, self.apellidos, self.fnac, self.calle, self.ciudad, self.cp = entries

        # --- Botones de acción (guardar y eliminar alumno) ---
        btn_frame = tk.Frame(self, bg=color_fondo)
        btn_frame.pack(pady=10)

        tk.Button(btn_frame, text='Guardar', command=self._guardar, bg=color_boton, fg=color_boton_texto,
                  font=fuente, width=15).grid(row=0, column=0, padx=10)
        tk.Button(btn_frame, text='Eliminar', command=self._eliminar, bg=color_boton, fg=color_boton_texto,
                  font=fuente, width=15).grid(row=0, column=1, padx=10)

        # --- Tabla para mostrar lista de alumnos registrados ---
        table_frame = tk.Frame(self, bg=color_fondo)
        table_frame.pack(pady=10)

        cols = ('id', 'nombre', 'apellidos', 'fecha_nacimiento', 'calle', 'ciudad', 'cp')
        self.tree = ttk.Treeview(table_frame, columns=cols, show='headings', height=10)
        for c in cols:
            self.tree.heading(c, text=c.title())
            self.tree.column(c, width=100)
        self.tree.pack()

        # Evento para seleccionar alumno desde la tabla
        self.tree.bind('<<TreeviewSelect>>', self._on_select)

        self.selected = None
        self._cargar_tabla()

    # Carga todos los alumnos desde el controlador a la tabla
    def _cargar_tabla(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for alum in self.ctrl.list_alumnos():
            self.tree.insert('', 'end', values=(
                alum.id,
                alum.nombre,
                alum.apellidos,
                alum.fecha_nacimiento,
                alum.calle,
                alum.ciudad,
                alum.cp
            ))

    # Guarda o actualiza los datos de un alumno
    def _guardar(self):
        data = {
            'nombre': self.nombre.get(),
            'apellidos': self.apellidos.get(),
            'fecha_nacimiento': self.fnac.get(),
            'calle': self.calle.get(),
            'ciudad': self.ciudad.get(),
            'cp': self.cp.get()
        }

        if not data['nombre'] or not data['apellidos']:
            messagebox.showwarning("Campos requeridos", "Nombre y Apellidos son obligatorios.")
            return

        if self.selected:
            self.ctrl.update_alumno(self.selected, data)
            messagebox.showinfo("Actualizado", "Alumno actualizado correctamente.")
        else:
            self.ctrl.add_alumno(data)
            messagebox.showinfo("Guardado", "Alumno guardado correctamente.")

        self._limpiar_campos()
        self._cargar_tabla()

    # Elimina el alumno seleccionado
    def _eliminar(self):
        if not self.selected:
            messagebox.showwarning("Selección requerida", "Selecciona un alumno para eliminar.")
            return

        confirmar = messagebox.askyesno("Confirmar eliminación", "¿Estás seguro de eliminar este alumno?")
        if confirmar:
            self.ctrl.delete_alumno(self.selected)
            self._limpiar_campos()
            self._cargar_tabla()
            messagebox.showinfo("Eliminado", "Alumno eliminado correctamente.")
            self.selected = None

    # Rellena el formulario con los datos del alumno seleccionado
    def _on_select(self, event):
        selected_item = self.tree.selection()
        if selected_item:
            item = selected_item[0]
            vals = self.tree.item(item)['values']
            self.nombre.delete(0, tk.END); self.nombre.insert(0, vals[1])
            self.apellidos.delete(0, tk.END); self.apellidos.insert(0, vals[2])
            self.fnac.delete(0, tk.END); self.fnac.insert(0, vals[3])
            self.calle.delete(0, tk.END); self.calle.insert(0, vals[4])
            self.ciudad.delete(0, tk.END); self.ciudad.insert(0, vals[5])
            self.cp.delete(0, tk.END); self.cp.insert(0, vals[6])

            # Busca el objeto alumno completo por ID para tenerlo en self.selected
            for alumno in self.ctrl.list_alumnos():
                if alumno.id == vals[0]:
                    self.selected = alumno
                    break

    # Limpia todos los campos del formulario
    def _limpiar_campos(self):
        self.nombre.delete(0, tk.END)
        self.apellidos.delete(0, tk.END)
        self.fnac.delete(0, tk.END)
        self.calle.delete(0, tk.END)
        self.ciudad.delete(0, tk.END)
        self.cp.delete(0, tk.END)
        self.selected = None

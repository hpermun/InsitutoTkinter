# Vista del menú principal de la aplicación con botones por rol
import tkinter as tk
from tkinter import filedialog, messagebox

# Importación de vistas disponibles en el sistema
from vista.alumno_vista import AlumnoView
from vista.profesor_vista import ProfesorView
from vista.aula_vista import AulaView
from vista.material_vista import MaterialView
from vista.asignatura_vista import AsignaturaView
from vista.clase_vista import ClaseView
from vista.calificaciones_vista import CalificacionesView
from vista.matricula_asignatura_vista import MatriculaAsignaturaView

# Clase principal del menú que se muestra tras iniciar sesión
class MenuView(tk.Tk):
    def __init__(self, nombre_usuario, rol):
        super().__init__()
        self.nombre_usuario = nombre_usuario
        self.rol = rol.lower()

        self.title(f'Menú Principal - Bienvenido {nombre_usuario} ({rol})')
        self.geometry("800x600")
        self.configure(bg="#f4f4f4")
        self.resizable(False, False)

        fuente = ("Segoe UI", 12)
        btn_color = "#2c2c2c"
        text_color = "#ffffff"
        disabled_color = "#cccccc"

        # Cabecera con información de la sesión
        header = tk.Frame(self, bg="#f4f4f4", pady=20)
        header.pack(fill="x")
        tk.Label(
            header,
            text=f"Sesión iniciada como: {nombre_usuario} ({rol})",
            font=("Segoe UI", 14, "bold"),
            bg="#f4f4f4",
            fg="#2c2c2c"
        ).pack()

        # Contenedor principal de botones
        container = tk.Frame(self, bg="#f4f4f4")
        container.pack(expand=True)

        # Lista de botones disponibles con su función y roles permitidos
        botones = [
            ("Inscripción Alumnos", lambda: AlumnoView(self), ['administrador', 'secretario']),
            ("Gestión Profesores", lambda: ProfesorView(self), ['administrador', 'secretario']),
            ("Gestión Aulas", lambda: AulaView(self), ['administrador', 'secretario']),
            ("Gestión Materiales", lambda: MaterialView(self), ['administrador', 'secretario']),
            ("Gestión Asignaturas", lambda: AsignaturaView(self), ['administrador', 'secretario']),
            ("Programación Clases", lambda: ClaseView(self, rol=self.rol), ['administrador', 'profesor', 'alumno']),
            ("Matricular Alumno", lambda: MatriculaAsignaturaView(self), ['administrador', 'secretario']),
            ("Calificaciones", lambda: CalificacionesView(self, año='2024-2025', rol=self.rol), ['administrador', 'profesor', 'alumno']),
            ("Importar Materiales", self._import_materiales, ['administrador', 'secretario']),
            ("Gestión de Pagos", self._abrir_pagos, ['administrador', 'secretario']),
        ]

        # Función para crear un botón según permisos
        def crear_boton_dashboard(texto, comando, permitido):
            color_fondo = btn_color if permitido else disabled_color
            color_texto = text_color if permitido else "#666666"

            return tk.Button(
                container,
                text=texto,
                width=25,
                height=2,
                font=fuente,
                bg=color_fondo,
                fg=color_texto,
                activebackground="#444444",
                relief=tk.FLAT,
                command=comando if permitido else lambda: messagebox.showwarning("Acceso denegado", "No tienes permisos para esta opción."),
                state="normal"
            )

        # Mostrar los botones en la interfaz según permisos del rol
        for i, (texto, accion, roles_permitidos) in enumerate(botones):
            permitido = self.rol in roles_permitidos
            fila, col = divmod(i, 2)
            btn = crear_boton_dashboard(texto, accion, permitido)
            btn.grid(row=fila, column=col, padx=20, pady=15)

        # Botón para cerrar la aplicación
        cerrar = tk.Button(
            self,
            text="Cerrar Aplicación",
            width=20,
            height=2,
            bg="#990000",
            fg="#ffffff",
            font=("Segoe UI", 12, "bold"),
            relief=tk.FLAT,
            command=self.destroy
        )
        cerrar.pack(pady=25)

        self.mainloop()

    # Permite importar materiales desde un archivo CSV
    def _import_materiales(self):
        path = filedialog.askopenfilename(filetypes=[('CSV', '*.csv')])
        if path:
            try:
                from controlador.material_controlador import MaterialController
                MaterialController().importar_desde_csv(path)
                messagebox.showinfo('Éxito', 'Materiales importados correctamente.')
            except Exception as e:
                messagebox.showerror('Error', f'Error al importar materiales:\n{str(e)}')

    # Abre la ventana de pagos
    def _abrir_pagos(self):
        try:
            from vista.pagos_vista import PagosView
            PagosView(self)
        except ImportError:
            messagebox.showwarning("Función no disponible", "La pantalla de pagos aún no está implementada.")

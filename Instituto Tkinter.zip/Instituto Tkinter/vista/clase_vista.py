# Vista para la gestión de clases (profesor, aula, asignatura y año)
import tkinter as tk
from tkinter import messagebox
from controlador.clase_controlador import ClaseController

# Ventana para gestionar las clases del sistema
class ClaseView(tk.Toplevel):
    def __init__(self, master=None, rol=None):
        super().__init__(master)
        self.title('Gestión de Clases')
        self.geometry("500x500")
        self.configure(bg="#f4f4f4")
        self.ctrl = ClaseController()
        self.rol = rol.lower() if rol else "usuario"
        self.selected = None

        es_lector = self.rol == "alumno"

        # Título y modo
        tk.Label(self, text='Gestión de Clases', font=("Segoe UI", 14, "bold"), bg="#f4f4f4", fg="#2c2c2c").pack(pady=10)

        if es_lector:
            tk.Label(self, text='(Modo solo lectura - Alumno)', fg='gray', bg="#f4f4f4").pack()

        # Formulario de entrada de datos
        form_frame = tk.Frame(self, bg="#f4f4f4")
        form_frame.pack(pady=10)

        self._crear_entrada(form_frame, "Profesor ID", "e_prof", es_lector)
        self._crear_entrada(form_frame, "Aula ID", "e_aula", es_lector)
        self._crear_entrada(form_frame, "Asignatura ID", "e_asig", es_lector)
        self._crear_entrada(form_frame, "Año Académico", "e_anio", es_lector)

        # Botones de acción (solo para roles que no son alumno)
        if not es_lector:
            tk.Button(self, text='Guardar', command=self._guardar, bg="#2c2c2c", fg="#ffffff", font=("Segoe UI", 10),
                      width=15).pack(pady=5)
            tk.Button(self, text='Eliminar', command=self._eliminar, bg="#880000", fg="#ffffff", font=("Segoe UI", 10),
                      width=15).pack(pady=5)

        # Lista de clases existentes
        self.lista = tk.Listbox(self, font=("Segoe UI", 10), height=10)
        self.lista.pack(fill='both', expand=True, padx=20, pady=10)
        self.lista.bind("<<ListboxSelect>>", self._on_select)

        self._cargar()

    # Crea campos de entrada reutilizables
    def _crear_entrada(self, master, texto, atributo, readonly=False):
        tk.Label(master, text=texto, bg="#f4f4f4", anchor="w", font=("Segoe UI", 10)).pack(anchor="w")
        entrada = tk.Entry(master, font=("Segoe UI", 10), width=30)
        if readonly:
            entrada.configure(state="disabled")
        entrada.pack(pady=3)
        setattr(self, atributo, entrada)

    # Guarda una nueva clase o actualiza una existente
    def _guardar(self):
        try:
            data = {
                'profesor_id': int(self.e_prof.get()),
                'aula_id': int(self.e_aula.get()),
                'asignatura_id': int(self.e_asig.get()),
                'año_academico': self.e_anio.get()
            }
            self.ctrl.add(data)
            self._cargar()
            self._limpiar()
            messagebox.showinfo("Guardado", "Clase guardada correctamente.")
        except ValueError:
            messagebox.showerror("Error", "Asegúrate de introducir IDs válidos.")

    # Elimina la clase seleccionada
    def _eliminar(self):
        if not self.selected:
            messagebox.showwarning("Selección requerida", "Selecciona una clase para eliminar.")
            return

        confirmar = messagebox.askyesno("Confirmar", "¿Seguro que deseas eliminar esta clase?")
        if confirmar:
            self.ctrl.delete(self.selected)
            self._cargar()
            self._limpiar()
            messagebox.showinfo("Eliminado", "Clase eliminada correctamente.")
            self.selected = None

    # Carga los datos de la clase seleccionada
    def _on_select(self, event):
        seleccion = self.lista.curselection()
        if seleccion:
            index = seleccion[0]
            clase = self.ctrl.list()[index]
            self.selected = clase

            self.e_prof.configure(state="normal")
            self.e_aula.configure(state="normal")
            self.e_asig.configure(state="normal")
            self.e_anio.configure(state="normal")

            self.e_prof.delete(0, tk.END); self.e_prof.insert(0, clase.profesor_id)
            self.e_aula.delete(0, tk.END); self.e_aula.insert(0, clase.aula_id)
            self.e_asig.delete(0, tk.END); self.e_asig.insert(0, clase.asignatura_id)
            self.e_anio.delete(0, tk.END); self.e_anio.insert(0, clase.año_academico)

            if self.rol == "alumno":
                self.e_prof.configure(state="disabled")
                self.e_aula.configure(state="disabled")
                self.e_asig.configure(state="disabled")
                self.e_anio.configure(state="disabled")

    # Carga todas las clases en la lista
    def _cargar(self):
        self.lista.delete(0, 'end')
        for c in self.ctrl.list():
            self.lista.insert('end', f'Clase {c.id} - Año {c.año_academico}')

    # Limpia los campos del formulario
    def _limpiar(self):
        self.e_prof.delete(0, tk.END)
        self.e_aula.delete(0, tk.END)
        self.e_asig.delete(0, tk.END)
        self.e_anio.delete(0, tk.END)
        self.selected = None

# Vista de inicio de sesión con soporte para login local y con Google
import tkinter as tk
from tkinter import messagebox
import sqlite3
from vista.menu_vista import MenuView
import webbrowser
from google_auth.google_login import login_con_google

# Ventana principal de login
class LoginView(tk.Tk):
    def __init__(self):
        super().__init__()
        self.success = False
        self.title("Inicio de sesión")
        self.geometry("400x450")
        self.configure(bg="#f4f4f4")
        self.resizable(False, False)

        fuente = ("Segoe UI", 12)
        btn_color = "#2c2c2c"
        text_color = "#ffffff"

        # Contenedor principal de la vista
        container = tk.Frame(self, bg="#f4f4f4", pady=40)
        container.pack(fill="both", expand=True)

        # Título
        tk.Label(
            container,
            text="Instituto TKINTER",
            font=("Segoe UI", 18, "bold"),
            bg="#f4f4f4",
            fg="#2c2c2c"
        ).pack(pady=(0, 20))

        # Campo usuario
        tk.Label(container, text="Usuario", font=fuente, bg="#f4f4f4").pack(pady=5)
        self.entry_usuario = tk.Entry(container, font=fuente, width=30)
        self.entry_usuario.pack()

        # Campo contraseña
        tk.Label(container, text="Contraseña", font=fuente, bg="#f4f4f4").pack(pady=5)
        self.entry_contrasena = tk.Entry(container, show="*", font=fuente, width=30)
        self.entry_contrasena.pack()

        # Botón de inicio de sesión
        tk.Button(
            container,
            text="Iniciar sesión",
            command=self.iniciar_sesion,
            bg=btn_color,
            fg=text_color,
            font=fuente,
            width=25
        ).pack(pady=15)

        # Enlace para recuperación de contraseña
        tk.Button(
            container,
            text="¿Olvidaste tu contraseña?",
            command=self.recuperar_contraseña,
            bg="#e0e0e0",
            font=("Segoe UI", 10),
            relief="flat"
        ).pack(pady=5)

        # Botón de inicio con Google
        tk.Button(
            container,
            text="Iniciar sesión con Google",
            command=self.login_con_google,
            bg="#4285F4",
            fg="white",
            font=("Segoe UI", 10, "bold")
        ).pack(pady=5)

    # Lógica para iniciar sesión con usuario y contraseña locales
    def iniciar_sesion(self):
        usuario = self.entry_usuario.get()
        contrasena = self.entry_contrasena.get()

        if not usuario or not contrasena:
            messagebox.showwarning("Campos vacíos", "Por favor, rellena todos los campos.")
            return

        try:
            conn = sqlite3.connect("instituto.db")
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()

            # Consulta que relaciona usuario con persona (nombre y rol)
            cursor.execute('''
                SELECT persona.nombre, persona.rol
                FROM usuario
                JOIN persona ON usuario.persona_id = persona.id
                WHERE usuario.username=? AND usuario.password=?
            ''', (usuario, contrasena))

            resultado = cursor.fetchone()
            conn.close()

            if resultado:
                nombre_usuario = resultado["nombre"]
                rol = resultado["rol"]
                messagebox.showinfo("Login correcto", f"Bienvenido {nombre_usuario} ({rol})")
                self.success = True
                self.destroy()
                MenuView(nombre_usuario, rol)
            else:
                messagebox.showerror("Error", "Usuario o contraseña incorrectos.")

        except sqlite3.Error as e:
            messagebox.showerror("Error de base de datos", str(e))

    # Simula recuperación de contraseña
    def recuperar_contraseña(self):
        usuario = self.entry_usuario.get()
        if not usuario:
            messagebox.showwarning("Atención", "Introduce tu nombre de usuario para recuperar la contraseña.")
            return
        messagebox.showinfo("Recuperar contraseña", f"Se ha enviado un correo para restablecer la contraseña de: {usuario}")

    # Inicio de sesión mediante autenticación con Google
    def login_con_google(self):
        try:
            nombre, email = login_con_google()
            messagebox.showinfo("Login con Google", f"Bienvenido {nombre}\n({email})")

            # Se asigna un rol ficticio por defecto
            self.success = True
            self.destroy()
            MenuView(nombre, "profesor")  # o el rol que prefieras asignar

        except Exception as e:
            messagebox.showerror("Error en login", f"No se pudo autenticar con Google.\n{str(e)}")

# Vista para seleccionar método de pago (simulado o real con Stripe)
import tkinter as tk
from tkinter import messagebox
from google_auth.payment_processor import crear_pago_matricula

# Ventana de pagos accesible desde el menú principal
class PagosView(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("Gestión de Pagos")
        self.geometry("400x400")
        self.configure(bg="#f4f4f4")
        self.resizable(False, False)

        fuente = ("Segoe UI", 12)
        btn_color = "#2c2c2c"
        text_color = "#ffffff"

        # Contenedor principal de la interfaz
        container = tk.Frame(self, bg="#f4f4f4", pady=20)
        container.pack(expand=True)

        # Título de la ventana
        tk.Label(
            container,
            text="Selecciona un método de pago",
            font=("Segoe UI", 16, "bold"),
            bg="#f4f4f4",
            fg="#2c2c2c"
        ).pack(pady=(10, 30))

        # Botón para pago real con Stripe
        tk.Button(
            container,
            text="💳 Tarjeta de crédito (Stripe)",
            width=30,
            command=self._pagar_tarjeta,
            bg=btn_color,
            fg=text_color,
            font=fuente
        ).pack(pady=10)

        # Botón para pago simulado con PayPal
        tk.Button(
            container,
            text="🅿️ PayPal (simulado)",
            width=30,
            command=self._pagar_paypal,
            bg="#0070BA",
            fg="white",
            font=fuente
        ).pack(pady=10)

        # Botón para pago simulado en efectivo
        tk.Button(
            container,
            text="💵 Efectivo (simulado)",
            width=30,
            command=self._pagar_efectivo,
            bg="#888888",
            fg="white",
            font=fuente
        ).pack(pady=10)

        # Botón para cerrar la ventana
        tk.Button(
            container,
            text="Cerrar",
            command=self.destroy,
            font=fuente,
            bg="#e0e0e0"
        ).pack(pady=30)

    # Inicia el proceso real de pago con Stripe
    def _pagar_tarjeta(self):
        try:
            crear_pago_matricula()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo iniciar el pago con tarjeta:\n{e}")

    # Simula un pago con PayPal
    def _pagar_paypal(self):
        messagebox.showinfo("Pago con PayPal", "Pago simulado con PayPal procesado con éxito.")

    # Simula un pago en efectivo
    def _pagar_efectivo(self):
        messagebox.showinfo("Pago en Efectivo", "Pago en efectivo registrado correctamente.")

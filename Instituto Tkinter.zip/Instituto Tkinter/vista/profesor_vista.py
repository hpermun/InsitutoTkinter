# Vista para la gestión de profesores: formulario, tabla y acciones CRUD
import tkinter as tk
from tkinter import ttk, messagebox
from controlador.persona_controlador import PersonaController

# Ventana para gestionar profesores del instituto
class ProfesorView(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title('Gestión Profesores')
        self.geometry("900x550")
        self.resizable(True, True)
        self.configure(bg="#f4f4f4")
        self.ctrl = PersonaController()

        fuente = ("Segoe UI", 10)
        color_fondo = "#f4f4f4"
        color_boton = "#2c2c2c"
        color_boton_texto = "#ffffff"

        # --- Formulario para ingresar datos del profesor ---
        form_frame = tk.Frame(self, bg=color_fondo)
        form_frame.grid(row=0, column=0, columnspan=2, padx=10, pady=10, sticky="w")

        # Campos del formulario
        tk.Label(form_frame, text='Nombre', bg=color_fondo, font=fuente).grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.nombre = tk.Entry(form_frame, font=fuente); self.nombre.grid(row=0, column=1, padx=5)

        tk.Label(form_frame, text='Apellidos', bg=color_fondo, font=fuente).grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.apellidos = tk.Entry(form_frame, font=fuente); self.apellidos.grid(row=1, column=1, padx=5)

        tk.Label(form_frame, text='Fecha Nac. (YYYY-MM-DD)', bg=color_fondo, font=fuente).grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.fnac = tk.Entry(form_frame, font=fuente); self.fnac.grid(row=2, column=1, padx=5)

        tk.Label(form_frame, text='Departamento', bg=color_fondo, font=fuente).grid(row=3, column=0, padx=5, pady=5, sticky="w")
        self.departamento = tk.Entry(form_frame, font=fuente); self.departamento.grid(row=3, column=1, padx=5)

        tk.Label(form_frame, text='Calle', bg=color_fondo, font=fuente).grid(row=4, column=0, padx=5, pady=5, sticky="w")
        self.calle = tk.Entry(form_frame, font=fuente); self.calle.grid(row=4, column=1, padx=5)

        tk.Label(form_frame, text='Ciudad', bg=color_fondo, font=fuente).grid(row=5, column=0, padx=5, pady=5, sticky="w")
        self.ciudad = tk.Entry(form_frame, font=fuente); self.ciudad.grid(row=5, column=1, padx=5)

        tk.Label(form_frame, text='CP', bg=color_fondo, font=fuente).grid(row=6, column=0, padx=5, pady=5, sticky="w")
        self.cp = tk.Entry(form_frame, font=fuente); self.cp.grid(row=6, column=1, padx=5)

        # --- Botones para guardar y eliminar ---
        btn_frame = tk.Frame(self, bg=color_fondo)
        btn_frame.grid(row=1, column=0, columnspan=2, pady=10)

        tk.Button(btn_frame, text='Guardar', command=self._guardar, bg=color_boton, fg=color_boton_texto,
                  font=fuente, width=15).grid(row=0, column=0, padx=10)
        tk.Button(btn_frame, text='Eliminar', command=self._eliminar, bg=color_boton, fg=color_boton_texto,
                  font=fuente, width=15).grid(row=0, column=1, padx=10)

        # --- Tabla que muestra los profesores registrados ---
        cols = ('id', 'nombre', 'apellidos', 'fecha_nacimiento', 'departamento', 'calle', 'ciudad', 'cp')
        self.tree = ttk.Treeview(self, columns=cols, show='headings', height=10)

        col_widths = {
            'id': 60,
            'nombre': 120,
            'apellidos': 150,
            'fecha_nacimiento': 120,
            'departamento': 120,
            'calle': 120,
            'ciudad': 100,
            'cp': 80
        }

        for c in cols:
            self.tree.heading(c, text=c.title())
            self.tree.column(c, width=col_widths.get(c, 100))

        self.tree.grid(row=2, column=0, columnspan=2, padx=10, pady=10, sticky="nsew")
        self.tree.bind('<<TreeviewSelect>>', self._on_select)

        self.grid_rowconfigure(2, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.selected = None
        self._cargar_tabla()

    # Carga todos los profesores en la tabla
    def _cargar_tabla(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for prof in self.ctrl.list_profesores():
            self.tree.insert('', 'end', values=(
                prof.id,
                prof.nombre,
                prof.apellidos,
                prof.fecha_nacimiento,
                getattr(prof, 'departamento', ''),
                getattr(prof, 'calle', ''),
                getattr(prof, 'ciudad', ''),
                getattr(prof, 'cp', '')
            ))

    # Guarda un nuevo profesor o actualiza el existente
    def _guardar(self):
        data = {
            'nombre': self.nombre.get(),
            'apellidos': self.apellidos.get(),
            'fecha_nacimiento': self.fnac.get(),
            'departamento': self.departamento.get(),
            'direccion': {
                'calle': self.calle.get(),
                'ciudad': self.ciudad.get(),
                'cp': self.cp.get()
            }
        }

        if not data['nombre'] or not data['apellidos']:
            messagebox.showwarning("Campos requeridos", "Nombre y Apellidos son obligatorios.")
            return

        if self.selected:
            self.ctrl.update_profesor(self.selected, data)
            messagebox.showinfo("Actualizado", "Profesor actualizado correctamente.")
        else:
            self.ctrl.add_profesor(data)
            messagebox.showinfo("Guardado", "Profesor guardado correctamente.")

        self._limpiar_campos()
        self._cargar_tabla()

    # Elimina al profesor seleccionado
    def _eliminar(self):
        if not self.selected:
            messagebox.showwarning("Selección requerida", "Selecciona un profesor para eliminar.")
            return

        confirmar = messagebox.askyesno("Confirmar eliminación", "¿Estás seguro de eliminar este profesor?")
        if confirmar:
            self.ctrl.delete_profesor(self.selected)
            self._limpiar_campos()
            self._cargar_tabla()
            messagebox.showinfo("Eliminado", "Profesor eliminado correctamente.")
            self.selected = None

    # Carga los datos del profesor seleccionado en el formulario
    def _on_select(self, event):
        selected_item = self.tree.selection()
        if selected_item:
            item = selected_item[0]
            vals = self.tree.item(item)['values']
            self.nombre.delete(0, tk.END); self.nombre.insert(0, vals[1])
            self.apellidos.delete(0, tk.END); self.apellidos.insert(0, vals[2])
            self.fnac.delete(0, tk.END); self.fnac.insert(0, vals[3])
            self.departamento.delete(0, tk.END); self.departamento.insert(0, vals[4])
            self.calle.delete(0, tk.END); self.calle.insert(0, vals[5])
            self.ciudad.delete(0, tk.END); self.ciudad.insert(0, vals[6])
            self.cp.delete(0, tk.END); self.cp.insert(0, vals[7])

            profesores = self.ctrl.list_profesores()
            self.selected = next((p for p in profesores if p.id == vals[0]), None)

    # Limpia todos los campos del formulario
    def _limpiar_campos(self):
        self.nombre.delete(0, tk.END)
        self.apellidos.delete(0, tk.END)
        self.fnac.delete(0, tk.END)
        self.departamento.delete(0, tk.END)
        self.calle.delete(0, tk.END)
        self.ciudad.delete(0, tk.END)
        self.cp.delete(0, tk.END)
        self.selected = None

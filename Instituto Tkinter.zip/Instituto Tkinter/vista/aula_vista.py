# Ventana para gestionar aulas (crear, actualizar, eliminar)
import tkinter as tk
from tkinter import ttk, messagebox
from controlador.aula_controlador import AulaController

class AulaView(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title('Gestión de Aulas')
        self.geometry("500x400")
        self.resizable(False, False)
        self.configure(bg="#f4f4f4")
        self.ctrl = AulaController()
        self.selected = None

        # --- Estilos generales ---
        fuente = ("Segoe UI", 10)
        color_fondo = "#f4f4f4"
        color_boton = "#2c2c2c"
        color_boton_texto = "#ffffff"

        # --- Formulario para ingresar datos del aula ---
        form_frame = tk.Frame(self, bg=color_fondo)
        form_frame.grid(row=0, column=0, columnspan=2, padx=10, pady=10)

        tk.Label(form_frame, text='Número de Aula', bg=color_fondo, font=fuente).grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.e_numero = tk.Entry(form_frame, font=fuente); self.e_numero.grid(row=0, column=1, padx=5)

        tk.Label(form_frame, text='Capacidad', bg=color_fondo, font=fuente).grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.e_capacidad = tk.Entry(form_frame, font=fuente); self.e_capacidad.grid(row=1, column=1, padx=5)

        # --- Botones para guardar o eliminar aula ---
        btn_frame = tk.Frame(self, bg=color_fondo)
        btn_frame.grid(row=1, column=0, columnspan=2, pady=5)

        tk.Button(btn_frame, text='Guardar', command=self._guardar, bg=color_boton, fg=color_boton_texto,
                  font=fuente, width=12).grid(row=0, column=0, padx=10, pady=10)

        tk.Button(btn_frame, text='Eliminar', command=self._eliminar, bg=color_boton, fg=color_boton_texto,
                  font=fuente, width=12).grid(row=0, column=1, padx=10, pady=10)

        # --- Tabla para mostrar aulas registradas ---
        cols = ('id', 'numero', 'capacidad')
        self.tree = ttk.Treeview(self, columns=cols, show='headings', height=10)

        self.tree.heading('id', text='ID')
        self.tree.heading('numero', text='Número')
        self.tree.heading('capacidad', text='Capacidad')
        self.tree.column('id', width=50)
        self.tree.column('numero', width=150)
        self.tree.column('capacidad', width=150)

        self.tree.grid(row=2, column=0, columnspan=2, padx=10, pady=10)
        self.tree.bind('<<TreeviewSelect>>', self._on_select)

        self._cargar()

    # Guarda o actualiza un aula según el estado de selección
    def _guardar(self):
        numero = self.e_numero.get()
        capacidad = self.e_capacidad.get()

        if not numero or not capacidad:
            messagebox.showwarning("Campos requeridos", "Número y capacidad son obligatorios.")
            return

        try:
            capacidad = int(capacidad)
        except ValueError:
            messagebox.showerror("Error", "La capacidad debe ser un número entero.")
            return

        data = {'numero': numero, 'capacidad': capacidad}

        if self.selected:
            self.ctrl.update(self.selected, data)
            messagebox.showinfo("Actualizado", "Aula actualizada correctamente.")
        else:
            self.ctrl.add(data)
            messagebox.showinfo("Guardado", "Aula guardada correctamente.")

        self._limpiar()
        self._cargar()

    # Elimina el aula seleccionada
    def _eliminar(self):
        if not self.selected:
            messagebox.showwarning("Selección requerida", "Selecciona un aula para eliminar.")
            return

        confirmar = messagebox.askyesno("Confirmar", "¿Seguro que deseas eliminar esta aula?")
        if confirmar:
            self.ctrl.delete(self.selected)
            self._limpiar()
            self._cargar()
            messagebox.showinfo("Eliminado", "Aula eliminada correctamente.")

    # Carga datos del aula seleccionada en el formulario
    def _on_select(self, event):
        selected_item = self.tree.selection()
        if selected_item:
            item = selected_item[0]
            vals = self.tree.item(item)['values']
            self.selected = vals[0]
            self.e_numero.delete(0, tk.END); self.e_numero.insert(0, vals[1])
            self.e_capacidad.delete(0, tk.END); self.e_capacidad.insert(0, vals[2])

    # Limpia los campos del formulario
    def _limpiar(self):
        self.selected = None
        self.e_numero.delete(0, tk.END)
        self.e_capacidad.delete(0, tk.END)

    # Carga todas las aulas en la tabla
    def _cargar(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for aula in self.ctrl.list():
            self.tree.insert('', 'end', values=(aula.id, aula.numero, aula.capacidad))

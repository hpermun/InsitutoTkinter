# Modelo que representa una convocatoria (nota de un alumno en una clase concreta)
from db import Database

class Convocatoria:
    def __init__(self, clase_id, tipo, fecha, nota, alumno_id, id=None):
        self.id = id
        self.clase_id = clase_id
        self.tipo = tipo
        self.fecha = fecha
        self.nota = nota
        self.alumno_id = alumno_id

    # Guarda la convocatoria en la base de datos (insert o update)
    def save(self):
        db = Database()
        if self.id:
            db.execute('UPDATE convocatoria SET clase_id=?, tipo=?, fecha=?, nota=?, alumno_id=? WHERE id=?',
                       (self.clase_id, self.tipo, self.fecha, self.nota, self.alumno_id, self.id))
        else:
            cur = db.execute('INSERT INTO convocatoria (clase_id, tipo, fecha, nota, alumno_id) VALUES (?,?,?,?,?)',
                             (self.clase_id, self.tipo, self.fecha, self.nota, self.alumno_id))
            self.id = cur.lastrowid

    # Elimina la convocatoria si tiene ID
    def delete(self):
        if not self.id: return
        db = Database()
        db.execute('DELETE FROM convocatoria WHERE id=?', (self.id,))

    # Devuelve todas las convocatorias almacenadas
    @staticmethod
    def get_all():
        db = Database()
        rows = db.execute('SELECT * FROM convocatoria').fetchall()
        return [Convocatoria(**row) for row in rows]

# Modelo que representa a un alumno, hereda de Persona
from modelo.persona import Persona

class Alumno(Persona):
    def __init__(self, **kwargs):
        # Se establece el tipo como 'alumno' al crear el objeto
        kwargs['tipo'] = 'alumno'
        super().__init__(**kwargs)
        self.matricula = kwargs.get('matricula', None)

    # Guarda el alumno en la base de datos (heredado de Persona)
    def save(self):
        super().save()

    # Devuelve todos los objetos de tipo alumno
    @staticmethod
    def get_all():
        return Persona.get_all(tipo='alumno')

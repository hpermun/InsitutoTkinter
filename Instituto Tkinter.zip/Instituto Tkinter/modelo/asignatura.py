# Modelo que representa una asignatura impartida por un profesor
from db import Database
from modelo.persona import Persona

class Asignatura:
    def __init__(self, nombre, departamento, profesor_id=None, id=None):
        self.id = id
        self.nombre = nombre
        self.departamento = departamento
        self.profesor_id = profesor_id

    # Guarda la asignatura en la base de datos (insert o update)
    def save(self):
        db = Database()
        if self.id:
            db.execute('UPDATE asignatura SET nombre=?, departamento=?, profesor_id=? WHERE id=?',
                       (self.nombre, self.departamento, self.profesor_id, self.id))
        else:
            cur = db.execute('INSERT INTO asignatura (nombre, departamento, profesor_id) VALUES (?, ?, ?)',
                             (self.nombre, self.departamento, self.profesor_id))
            self.id = cur.lastrowid

    # Elimina la asignatura si existe
    def delete(self):
        if not self.id: return
        db = Database()
        db.execute('DELETE FROM asignatura WHERE id=?', (self.id,))

    # Obtiene todas las asignaturas desde la base de datos
    @staticmethod
    def get_all():
        db = Database()
        rows = db.execute('SELECT * FROM asignatura').fetchall()
        return [Asignatura(**row) for row in rows]

    # Obtiene una asignatura concreta por su ID
    @staticmethod
    def get_by_id(id_):
        db = Database()
        row = db.execute('SELECT * FROM asignatura WHERE id=?', (id_,)).fetchone()
        return Asignatura(**row) if row else None

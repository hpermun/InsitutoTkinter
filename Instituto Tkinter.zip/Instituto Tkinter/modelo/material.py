# Modelo Material: representa un objeto físico asociado a un aula
from db import Database

class Material:
    def __init__(self, nombre, descripcion='', aula_id=None, id=None):
        self.id = id
        self.nombre = nombre
        self.descripcion = descripcion
        self.aula_id = aula_id  # Relación con un aula concreta

    # Guarda el material en la base de datos (insert o update)
    def save(self):
        db = Database()
        if self.id:
            db.execute('UPDATE material SET nombre=?, descripcion=?, aula_id=? WHERE id=?',
                       (self.nombre, self.descripcion, self.aula_id, self.id))
        else:
            cur = db.execute('INSERT INTO material (nombre, descripcion, aula_id) VALUES (?,?,?)',
                             (self.nombre, self.descripcion, self.aula_id))
            self.id = cur.lastrowid

    # Elimina el material si tiene ID
    def delete(self):
        if not self.id: return
        db = Database()
        db.execute('DELETE FROM material WHERE id=?', (self.id,))

    # Devuelve todos los materiales registrados
    @staticmethod
    def get_all():
        db = Database()
        rows = db.execute('SELECT * FROM material').fetchall()
        return [Material(**row) for row in rows]

# Clase base Persona: se usa como modelo general para alumnos, profesores, dirección, etc.
from db import Database

class Persona:
    def __init__(self, nombre, apellidos, fecha_nacimiento=None, tipo='alumno',
                 rol=None, departamento=None, calle=None, ciudad=None, cp=None, id=None):
        self.id = id
        self.nombre = nombre
        self.apellidos = apellidos
        self.fecha_nacimiento = fecha_nacimiento
        self.tipo = tipo  # Define si es alumno, profesor, dirección, etc.
        self.rol = rol
        self.departamento = departamento
        self.calle = calle
        self.ciudad = ciudad
        self.cp = cp

    # Guarda los datos en la tabla persona (insert o update)
    def save(self):
        db = Database()
        if self.id:
            db.execute(
                '''
                UPDATE persona SET nombre=?, apellidos=?, fecha_nacimiento=?, tipo=?,
                    rol=?, departamento=?, calle=?, ciudad=?, cp=?
                WHERE id=?
                ''',
                (
                    self.nombre, self.apellidos, self.fecha_nacimiento, self.tipo,
                    self.rol, self.departamento, self.calle, self.ciudad, self.cp, self.id
                )
            )
        else:
            cur = db.execute(
                '''
                INSERT INTO persona (nombre, apellidos, fecha_nacimiento, tipo,
                    rol, departamento, calle, ciudad, cp)
                VALUES (?,?,?,?,?,?,?,?,?)
                ''',
                (
                    self.nombre, self.apellidos, self.fecha_nacimiento, self.tipo,
                    self.rol, self.departamento, self.calle, self.ciudad, self.cp
                )
            )
            self.id = cur.lastrowid

    # Elimina la persona si tiene ID
    def delete(self):
        if not self.id:
            return
        db = Database()
        db.execute('DELETE FROM persona WHERE id=?', (self.id,))

    # Obtiene todas las personas del tipo especificado (o todas si tipo=None)
    @classmethod
    def get_all(cls, tipo=None):
        db = Database()
        if tipo:
            rows = db.execute('SELECT * FROM persona WHERE tipo=?', (tipo,)).fetchall()
        else:
            rows = db.execute('SELECT * FROM persona').fetchall()
        return [cls(**row) for row in rows]

# Modelo Profesor: hereda de Persona y establece automáticamente tipo='profesor'
from modelo.persona import Persona

class Profesor(Persona):
    def __init__(self, **kwargs):
        direccion = kwargs.pop("direccion", {})  # Se extrae la subestructura 'direccion' si existe
        kwargs.update(direccion)  # Se incorpora en los atributos del profesor
        super().__init__(tipo='profesor', **kwargs)  # Se inicializa como tipo 'profesor'

    # Devuelve todos los objetos de tipo profesor
    @staticmethod
    def get_all():
        return Persona.get_all(tipo='profesor')

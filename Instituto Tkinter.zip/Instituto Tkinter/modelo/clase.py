# Modelo que representa una clase que une profesor, aula y asignatura
from db import Database

class Clase:
    def __init__(self, profesor_id, aula_id, asignatura_id, año_academico, id=None):
        self.id = id
        self.profesor_id = profesor_id
        self.aula_id = aula_id
        self.asignatura_id = asignatura_id
        self.año_academico = año_academico

    # Guarda la clase (insert o update según si tiene ID)
    def save(self):
        db = Database()
        if self.id:
            db.execute('UPDATE clase SET profesor_id=?, aula_id=?, asignatura_id=?, año_academico=? WHERE id=?',
                       (self.profesor_id, self.aula_id, self.asignatura_id, self.año_academico, self.id))
        else:
            cur = db.execute('INSERT INTO clase (profesor_id, aula_id, asignatura_id, año_academico) VALUES (?,?,?,?)',
                             (self.profesor_id, self.aula_id, self.asignatura_id, self.año_academico))
            self.id = cur.lastrowid

    # Elimina la clase si tiene ID
    def delete(self):
        if not self.id: return
        db = Database()
        db.execute('DELETE FROM clase WHERE id=?', (self.id,))

    # Devuelve todas las clases registradas
    @staticmethod
    def get_all():
        db = Database()
        rows = db.execute('SELECT * FROM clase').fetchall()
        return [Clase(**row) for row in rows]

    # Devuelve una clase por su ID
    @staticmethod
    def get_by_id(id_):
        db = Database()
        row = db.execute('SELECT * FROM clase WHERE id=?', (id_,)).fetchone()
        return Clase(**row) if row else None

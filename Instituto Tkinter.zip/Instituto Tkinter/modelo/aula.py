# Modelo que representa un aula física del instituto
from db import Database

class Aula:
    def __init__(self, numero, capacidad, id=None):
        self.id = id
        self.numero = numero
        self.capacidad = capacidad

    # Guarda el aula en la base de datos (insert o update)
    def save(self):
        db = Database()
        if self.id:
            db.execute('UPDATE aula SET numero=?, capacidad=? WHERE id=?', (self.numero, self.capacidad, self.id))
        else:
            cur = db.execute('INSERT INTO aula (numero, capacidad) VALUES (?,?)', (self.numero, self.capacidad))
            self.id = cur.lastrowid

    # Elimina el aula si tiene ID
    def delete(self):
        if not self.id: return
        db = Database()
        db.execute('DELETE FROM aula WHERE id=?', (self.id,))

    # Devuelve todas las aulas registradas
    @staticmethod
    def get_all():
        db = Database()
        rows = db.execute('SELECT * FROM aula').fetchall()
        return [Aula(**row) for row in rows]

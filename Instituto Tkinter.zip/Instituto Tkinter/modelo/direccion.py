# Modelo Direccion, hereda de Persona con tipo predefinido como 'direccion'
from modelo.persona import Persona

class Direccion(Persona):
    def __init__(self, nombre, apellidos, fecha_nacimiento=None, rol=None, id=None):
        # Se inicializa como tipo 'direccion' y se pasa a la clase Persona
        super().__init__(nombre, apellidos, fecha_nacimiento, tipo='direccion', rol=rol)
        if id: self.id = id  # Si se pasa un ID, se asigna directamente

    # Guarda la dirección en la base de datos (mismo método que Persona)
    def save(self):
        super().save()

    # Obtiene todas las personas que tienen tipo 'direccion'
    @staticmethod
    def get_all():
        return Persona.get_all(tipo='direccion')

# precargar_datos.py
from db import Database

db = Database()

def insertar_persona(nombre, apellidos, fecha, tipo, rol, depto, calle, ciudad, cp):
    return db.execute("""INSERT INTO persona (nombre, apellidos, fecha_nacimiento, tipo, rol, departamento, calle, ciudad, cp)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                      (nombre, apellidos, fecha, tipo, rol, depto, calle, ciudad, cp)).lastrowid

# Profesores (todos de Gines y Espartinas)
profesores = [
    ("Lucía", "Gómez", "1980-02-10", "Lengua", "Calle Real, 45", "Gines", "41960"),
    ("Carlos", "Ruiz", "1975-06-20", "Matemáticas", "Av. de Europa, 21", "Espartinas", "41807"),
    ("Ana", "Lozano", "1982-01-15", "Educación Física", "C/ Camino del Molino, 9", "Gines", "41960"),
    ("Pablo", "Santos", "1979-11-05", "Física y Química", "Calle Almendro, 18", "Espartinas", "41807"),
    ("Elena", "Navarro", "1984-03-30", "Historia", "Calle Colón, 5", "Gines", "41960")
]

prof_ids = []
for nombre, apellidos, fecha, depto, calle, ciudad, cp in profesores:
    prof_ids.append(insertar_persona(nombre, apellidos, fecha, "profesor", "profesor", depto, calle, ciudad, cp))

# Alumnos (con edades de 15 a 17 años)
alumnos = [
    ("Martín", "Pérez", "2008-04-10", "Calle Rosario, 22", "Gines", "41960"),
    ("Laura", "Sánchez", "2007-06-21", "Av. de Andalucía, 12", "Gines", "41960"),
    ("Javier", "Muñoz", "2009-09-17", "Calle Verdial, 6", "Espartinas", "41807"),
    ("Sofía", "Romero", "2008-01-11", "Plaza de España, 4", "Espartinas", "41807"),
    ("Diego", "López", "2008-12-05", "Calle San Ginés, 33", "Gines", "41960")
]

alum_ids = []
for nombre, apellidos, fecha, calle, ciudad, cp in alumnos:
    alum_ids.append(insertar_persona(nombre, apellidos, fecha, "alumno", "alumno", "ESO", calle, ciudad, cp))

# Aulas
aulas = [("101A", 30), ("102B", 25), ("103C", 20), ("104D", 28), ("105E", 22)]
aula_ids = []
for numero, cap in aulas:
    aula_ids.append(db.execute("INSERT INTO aula (numero, capacidad) VALUES (?, ?)", (numero, cap)).lastrowid)

# Asignaturas
asignaturas = [
    ("Lengua", "Lengua", prof_ids[0]),
    ("Matemáticas", "Ciencias", prof_ids[1]),
    ("Educación Física", "Cuerpo y salud", prof_ids[2]),
    ("Física y Química", "Ciencias", prof_ids[3]),
    ("Historia", "Ciencias Sociales", prof_ids[4])
]

asig_ids = []
for nombre, depto, prof_id in asignaturas:
    asig_ids.append(db.execute("INSERT INTO asignatura (nombre, departamento, profesor_id) VALUES (?, ?, ?)",
                               (nombre, depto, prof_id)).lastrowid)

# Relación alumno ↔ asignatura (sin duplicados, con variedad)
matriculas = {
    alum_ids[0]: [asig_ids[0], asig_ids[1], asig_ids[3]],         # Martín
    alum_ids[1]: [asig_ids[0], asig_ids[2], asig_ids[4]],         # Laura
    alum_ids[2]: [asig_ids[1], asig_ids[3]],                      # Javier
    alum_ids[3]: [asig_ids[2], asig_ids[4]],                      # Sofía
    alum_ids[4]: [asig_ids[0], asig_ids[1], asig_ids[2], asig_ids[3], asig_ids[4]]  # Diego (completo)
}

# Insertar en tabla intermedia alumno_asignatura
for alumno_id, asigns in matriculas.items():
    for asign_id in asigns:
        db.execute("INSERT OR IGNORE INTO alumno_asignatura (alumno_id, asignatura_id) VALUES (?, ?)",
                   (alumno_id, asign_id))

# Crear clases (asignatura + profesor + aula)
clase_ids = []
for asign_id, aula_id, prof_id in zip(asig_ids, aula_ids, prof_ids):
    clase_ids.append(
        db.execute("INSERT INTO clase (profesor_id, aula_id, asignatura_id, año_academico) VALUES (?, ?, ?, ?)",
                   (prof_id, aula_id, asign_id, "2024/2025")).lastrowid
    )

# Insertar una sola convocatoria (final) por alumno y asignatura
notas_finales = {
    alum_ids[0]: [8.5, 7.0, 6.2],      # Martín
    alum_ids[1]: [9.0, 6.8, 7.5],      # Laura
    alum_ids[2]: [4.9, 5.3],           # Javier (suspenso en una)
    alum_ids[3]: [6.0, 7.8],           # Sofía
    alum_ids[4]: [8.0, 7.5, 9.2, 6.7, 5.0]  # Diego
}

for alumno_id, asigns in matriculas.items():
    for i, asign_id in enumerate(asigns):
        clase = db.execute("SELECT id FROM clase WHERE asignatura_id = ?", (asign_id,)).fetchone()
        if clase:
            clase_id = clase["id"]
            nota = notas_finales[alumno_id][i]
            db.execute("INSERT INTO convocatoria (clase_id, tipo, fecha, nota, alumno_id) VALUES (?, ?, ?, ?, ?)",
                       (clase_id, "Final", "2025-06-10", nota, alumno_id))

print("✅ Datos precargados con realismo, sin duplicados y listos para producción.")

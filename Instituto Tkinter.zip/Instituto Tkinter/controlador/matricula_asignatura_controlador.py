# Controlador para matricular alumnos en asignaturas
from db import Database
from tkinter import messagebox

# Obtiene todas las asignaturas disponibles
def obtener_asignaturas():
    db = Database()
    cursor = db.cursor
    cursor.execute("SELECT id, nombre FROM asignatura")
    asignaturas = cursor.fetchall()
    return [(row["id"], row["nombre"]) for row in asignaturas]

# Matricula a un alumno en una lista de asignaturas
def matricular_alumno(alumno_id, asignaturas_ids):
    db = Database()
    cursor = db.cursor
    errores = []
    for asignatura_id in asignaturas_ids:
        cursor.execute(
            "SELECT COUNT(*) AS cuenta FROM alumno_asignatura WHERE alumno_id = ? AND asignatura_id = ?",
            (alumno_id, asignatura_id)
        )
        if cursor.fetchone()["cuenta"] == 0:
            cursor.execute(
                "INSERT INTO alumno_asignatura (alumno_id, asignatura_id) VALUES (?, ?)",
                (alumno_id, asignatura_id)
            )
        else:
            errores.append(asignatura_id)
    db.conn.commit()
    return errores

# Controlador de lógica para la entidad Clase (programación de clases)
from db import Database
from modelo.clase import Clase

class ClaseController:
    def __init__(self):
        self.db = Database()  # Inicializa la conexión a la BD

    # Añade una nueva clase
    def add(self, data):
        Clase(**data).save()

    # Lista todas las clases
    def list(self):
        return Clase.get_all()

    # Actualiza una clase existente
    def update(self, inst, data):
        for k, v in data.items():
            setattr(inst, k, v)
        inst.save()

    # Elimina una clase (por objeto o por ID)
    def delete(self, inst):
        if isinstance(inst, Clase):
            inst.delete()
        else:
            clase = next((c for c in Clase.get_all() if c.id == inst), None)
            if clase:
                clase.delete()

    # Devuelve una clase por ID
    def get(self, id_):
        return Clase.get_by_id(id_)

    # Devuelve las asignaturas matriculadas por un alumno usando JOIN
    def get_asignaturas_matriculadas_por_alumno(self, alumno_id):
        query = '''
            SELECT clase.id, clase.asignatura_id
            FROM clase
            JOIN alumno_asignatura ON clase.asignatura_id = alumno_asignatura.asignatura_id
            WHERE alumno_asignatura.alumno_id = ?
        '''
        return self.db.execute(query, (alumno_id,)).fetchall()

    # Devuelve todas las asignaturas con su nombre en formato lista de diccionarios
    def get_todas_asignaturas_con_nombre(self):
        rows = Database().execute("""
            SELECT asignatura.id, asignatura.nombre
            FROM asignatura
        """).fetchall()
        return [dict(row) for row in rows]

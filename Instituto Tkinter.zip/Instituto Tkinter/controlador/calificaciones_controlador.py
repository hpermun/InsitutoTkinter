# controlador/convocatoria_controlador.py

# Importación de los modelos necesarios
from modelo.clase import Clase
from modelo.asignatura import Asignatura
from modelo.convocatoria import Convocatoria 

# Devuelve una instancia de Clase a partir del ID
def get_clase(self, clase_id):
    from modelo.clase import Clase  # Importación interna (opcional)
    return Clase.get_by_id(clase_id)

# Devuelve una instancia de Asignatura a partir del ID
def get_asignatura(self, asignatura_id):
    from modelo.asignatura import Asignatura  # Importación interna (opcional)
    return Asignatura.get_by_id(asignatura_id)

# Devuelve una instancia de Clase por ID (versión directa)
def get_clase(self, clase_id):
    return Clase.get_by_id(clase_id)

# Devuelve una instancia de Asignatura por ID (versión directa)
def get_asignatura(self, asignatura_id):
    return Asignatura.get_by_id(asignatura_id)

# Controlador para gestionar alumnos, profesores y direcciones
from modelo.alumno import Alumno
from modelo.profesor import Profesor

class PersonaController:
    # ----------------- ALUMNOS -----------------

    # Añade un nuevo alumno
    def add_alumno(self, data):
        direccion = data.pop("direccion", {})
        data.update(direccion)
        alumno = Alumno(**data)
        alumno.save()

    # Lista todos los alumnos
    def list_alumnos(self):
        return Alumno.get_all()

    # Actualiza un alumno existente
    def update_alumno(self, instance, data):
        direccion = data.pop("direccion", {})
        data.update(direccion)
        for k, v in data.items():
            setattr(instance, k, v)
        instance.save()

    # Elimina un alumno
    def delete_alumno(self, instance):
        instance.delete()

    # ----------------- PROFESORES -----------------

    # Añade un nuevo profesor
    def add_profesor(self, data):
        direccion = data.pop("direccion", {})
        data.update(direccion)
        profesor = Profesor(**data)
        profesor.save()

    # Lista todos los profesores
    def list_profesores(self):
        return Profesor.get_all()

    # Actualiza un profesor existente
    def update_profesor(self, instance, data):
        direccion = data.pop("direccion", {})
        data.update(direccion)
        for k, v in data.items():
            setattr(instance, k, v)
        instance.save()

    # Elimina un profesor
    def delete_profesor(self, instance):
        instance.delete()

    # ----------------- DIRECCIONES -----------------

    # Lista personas que tienen una dirección registrada
    def list_direccion(self):
        # Devuelve personas (alumnos y profesores) que tengan dirección asignada
        return [p for p in Alumno.get_all() + Profesor.get_all() if p.calle or p.ciudad or p.cp]

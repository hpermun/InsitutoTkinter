# Controlador para manejar lógica de las asignaturas
from modelo.asignatura import Asignatura
from modelo.profesor import Profesor

class AsignaturaController:
    # Añade una asignatura si el profesor existe
    def add(self, data):
        if not self.profesor_existe(data.get("profesor_id")):
            raise ValueError("El ID del profesor no es válido.")
        Asignatura(**data).save()

    # Devuelve todas las asignaturas
    def list(self):
        return Asignatura.get_all()

    # Actualiza una asignatura por ID
    def update(self, id_asignatura, data):
        asignatura = next((a for a in self.list() if a.id == id_asignatura), None)
        if asignatura:
            for k, v in data.items():
                setattr(asignatura, k, v)
            asignatura.save()

    # Elimina una asignatura por ID
    def delete(self, id_asignatura):
        asignatura = next((a for a in self.list() if a.id == id_asignatura), None)
        if asignatura:
            asignatura.delete()

    # Comprueba si existe un profesor con ese ID
    def profesor_existe(self, profesor_id):
        return any(p.id == profesor_id for p in Profesor.get_all())

    # Devuelve el objeto Profesor por ID
    def get_profesor(self, profesor_id):
        prof = next((p for p in Profesor.get_all() if p.id == profesor_id), None)
        return prof

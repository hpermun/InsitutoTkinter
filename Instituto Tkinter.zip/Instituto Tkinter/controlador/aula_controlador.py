# Controlador para la lógica de gestión de aulas
from modelo.aula import Aula

class AulaController:
    # Añade un aula nueva
    def add(self, data):
        Aula(**data).save()

    # Lista todas las aulas
    def list(self):
        return Aula.get_all()

    # Actualiza una instancia de aula
    def update(self, inst, data):
        for k, v in data.items():
            setattr(inst, k, v)
        inst.save()

    # Elimina un aula por ID
    def delete(self, aula_id):
        inst = next((a for a in self.list() if a.id == aula_id), None)
        if inst:
            inst.delete()

# Controlador para gestionar materiales
import csv
from modelo.material import Material

class MaterialController:
    # Añade un nuevo material
    def add(self, data):
        Material(**data).save()

    # Lista todos los materiales
    def list(self):
        return Material.get_all()

    # Actualiza un material existente
    def update(self, inst, data):
        for k, v in data.items():
            setattr(inst, k, v)
        inst.save()

    # Elimina un material por ID
    def delete(self, material_id):
        inst = next((m for m in self.list() if m.id == material_id), None)
        if inst:
            inst.delete()

    # Importa materiales desde un archivo CSV
    def importar_desde_csv(self, path):
        with open(path, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                Material(row['nombre'], row.get('descripcion', ''), row.get('aula_id')).save()

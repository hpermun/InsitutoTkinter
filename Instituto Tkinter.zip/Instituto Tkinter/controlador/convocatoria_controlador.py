# Controlador para gestionar operaciones sobre convocatorias
from db import Database
from modelo.convocatoria import Convocatoria

class ConvocatoriaController:
    # Añade una nueva convocatoria usando un diccionario de datos
    def add(self, data):
        Convocatoria(**data).save()

    # Crea una convocatoria directamente con los parámetros indicados
    def crear(self, clase_id, tipo, fecha, nota, alumno_id):
        db = Database()
        db.execute("""
            INSERT INTO convocatoria (clase_id, tipo, fecha, nota, alumno_id)
            VALUES (?, ?, ?, ?, ?)
        """, (clase_id, tipo, fecha, nota, alumno_id))

    # Lista las convocatorias de un alumno para un año concreto
    def list_por_alumno_y_anio(self, alumno_id, año):
        rows = Database().execute(
            'SELECT * FROM convocatoria WHERE alumno_id=?', (alumno_id,)
        ).fetchall()
        return [Convocatoria(**row) for row in rows]

    # Actualiza la nota de una convocatoria concreta
    def actualizar_nota(self, alumno_id, clase_id, fecha, nueva_nota):
        Database().execute("""
            UPDATE convocatoria
            SET nota = ?
            WHERE alumno_id = ? AND clase_id = ? AND fecha = ?
        """, (nueva_nota, alumno_id, clase_id, fecha))

    # Obtiene todas las calificaciones con información extendida (alumno, asignatura, tipo, nota)
    def obtener_todas_las_calificaciones(self):
        rows = Database().execute("""
            SELECT p.nombre, p.apellidos, a.nombre AS nombre_materia, conv.tipo AS nombre_convocatoria, conv.nota
            FROM convocatoria conv
            JOIN clase cl ON conv.clase_id = cl.id
            JOIN asignatura a ON cl.asignatura_id = a.id
            JOIN persona p ON conv.alumno_id = p.id
        """).fetchall()

        print(f"DEBUG - Filas encontradas (sin filtrar por año): {len(rows)}")
        return [dict(row) for row in rows]

    # Obtiene calificaciones de una asignatura específica
    def obtener_calificaciones_por_materia(self, materia_id, año):
        rows = Database().execute("""
            SELECT p.nombre, p.apellidos, conv.tipo AS nombre_convocatoria, conv.nota
            FROM convocatoria conv
            JOIN clase cl ON conv.clase_id = cl.id
            JOIN persona p ON conv.alumno_id = p.id
            WHERE cl.asignatura_id = ?
        """, (materia_id,)).fetchall()
        return [dict(row) for row in rows]

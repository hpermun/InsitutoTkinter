from vista.login_vista import LoginView
from vista.menu_vista import MenuView
from db import Database  # <- añadido
import sys

if __name__ == '__main__':
    Database()  # <- añadido para forzar creación de tablas

    # Iniciar ventana de login
    login = LoginView()
    login.mainloop()

    # Verificar si el login fue exitoso
    if getattr(login, 'success', False):
        # Extraer nombre de usuario y rol
        usuario = getattr(login, 'nombre_usuario', 'Usuario')
        rol = getattr(login, 'rol', None)

        if rol:
            # Abrir menú con datos reales
            menu = MenuView(usuario, rol)
            menu.mainloop()

    # Cuando se cierra el menú o no hay login, termina completamente
    sys.exit()

import sqlite3

class Database:
    _instance = None

    def __new__(cls, db_file='instituto.db'):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.conn = sqlite3.connect(db_file)
            cls._instance.conn.row_factory = sqlite3.Row
            cls._instance.cursor = cls._instance.conn.cursor()
            cls._instance._create_tables()
        return cls._instance

    def _create_tables(self):
        # Personas
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS persona (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                apellidos TEXT NOT NULL,
                fecha_nacimiento TEXT,
                tipo TEXT NOT NULL,
                rol TEXT,
                departamento TEXT,
                calle TEXT,
                ciudad TEXT,
                cp TEXT
            )
        ''')

        # Aulas
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS aula (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                numero TEXT UNIQUE NOT NULL,
                capacidad INTEGER
            )
        ''')

        # Materiales
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS material (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                descripcion TEXT,
                aula_id INTEGER,
                FOREIGN KEY(aula_id) REFERENCES aula(id)
            )
        ''')

        # Asignaturas (actualizado con profesor_id)
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS asignatura (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                departamento TEXT,
                profesor_id INTEGER,
                FOREIGN KEY(profesor_id) REFERENCES persona(id)
            )
        ''')

        # Clases
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS clase (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                profesor_id INTEGER,
                aula_id INTEGER,
                asignatura_id INTEGER,
                año_academico TEXT,
                FOREIGN KEY(profesor_id) REFERENCES persona(id),
                FOREIGN KEY(aula_id) REFERENCES aula(id),
                FOREIGN KEY(asignatura_id) REFERENCES asignatura(id)
            )
        ''')

        # Convocatorias
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS convocatoria (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                clase_id INTEGER,
                tipo TEXT,
                fecha TEXT,
                nota REAL,
                alumno_id INTEGER,
                FOREIGN KEY(clase_id) REFERENCES clase(id),
                FOREIGN KEY(alumno_id) REFERENCES persona(id)
            )
        ''')

        # Usuarios
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS usuario (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                persona_id INTEGER,
                FOREIGN KEY(persona_id) REFERENCES persona(id)
            )
        ''')

        # Relación alumno-asignatura
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS alumno_asignatura (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                alumno_id INTEGER NOT NULL,
                asignatura_id INTEGER NOT NULL,
                UNIQUE(alumno_id, asignatura_id),
                FOREIGN KEY(alumno_id) REFERENCES persona(id),
                FOREIGN KEY(asignatura_id) REFERENCES asignatura(id)
            )
        ''')

        self.conn.commit()

        # --- Datos de prueba (si no existen usuarios) ---
        count = self.cursor.execute('SELECT COUNT(*) AS cnt FROM usuario').fetchone()['cnt']
        if count == 0:
            # Admin
            persona_admin_id = self.cursor.execute('''
                INSERT INTO persona (nombre, apellidos, fecha_nacimiento, tipo, rol, departamento)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', ('Administrador', 'Del Sistema', '1990-01-01', 'administrador', 'administrador', 'Dirección')).lastrowid

            self.cursor.execute('''
                INSERT INTO usuario (username, password, persona_id)
                VALUES (?, ?, ?)
            ''', ('admin', 'admin12345', persona_admin_id))

            # Secretario
            persona_sec_id = self.cursor.execute('''
                INSERT INTO persona (nombre, apellidos, fecha_nacimiento, tipo, rol, departamento)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', ('Sara', 'Secretaria', '1985-04-10', 'secretario', 'secretario', 'Administración')).lastrowid

            self.cursor.execute('''
                INSERT INTO usuario (username, password, persona_id)
                VALUES (?, ?, ?)
            ''', ('secretario', 'secretario12345', persona_sec_id))

            # Profesor de ejemplo
            profesor_id = self.cursor.execute('''
                INSERT INTO persona (nombre, apellidos, fecha_nacimiento, tipo, rol, departamento)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', ('Miguel', 'Hernández', '1980-09-15', 'profesor', 'docente', 'Lenguas')).lastrowid

            # Asignatura con profesor asignado
            self.cursor.execute('''
                INSERT INTO asignatura (nombre, departamento, profesor_id)
                VALUES (?, ?, ?)
            ''', ('Lenguaje', 'Lenguas', profesor_id))

            self.conn.commit()

    def execute(self, query, params=()):
        try:
            cur = self.cursor.execute(query, params)
            self.conn.commit()
            return cur
        except sqlite3.Error as e:
            print(f"Error BD: {e}")
            return None

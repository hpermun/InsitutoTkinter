import stripe
import webbrowser

# Clave secreta de Stripe en modo de prueba
stripe.api_key = "sk_test_51RUXWNQMoEdEdqlBa3coJbrXgpsSCcG6treqQPV5EM94pTqxf7qkbpAKXbVOLarJJbDPMVROl24MgZTn4xm6bdug00fLHXQNIL"

def crear_pago_matricula():
    try:
        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[{
                "price_data": {
                    "currency": "eur",
                    "product_data": {
                        "name": "Pago de matrícula - Instituto TKINTER"
                    },
                    "unit_amount": 1000  # 10.00€ (1000 centavos)
                },
                "quantity": 1
            }],
            mode="payment",
            success_url="https://institutotkinter.local/success",
            cancel_url="https://institutotkinter.local/cancel"
        )

        # Abre la URL de pago en el navegador
        webbrowser.open(session.url)

    except Exception as e:
        print(f"Error creando sesión de pago: {e}")

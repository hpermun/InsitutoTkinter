from google_auth_oauthlib.flow import InstalledAppFlow

def login_con_google():
    SCOPES = ['openid', 'https://www.googleapis.com/auth/userinfo.profile', 'https://www.googleapis.com/auth/userinfo.email']
    
    flow = InstalledAppFlow.from_client_secrets_file(
        'google_auth/credentials.json',  # Asegúrate de que la ruta sea correcta
        scopes=SCOPES
    )

    creds = flow.run_local_server(port=0)
    session = flow.authorized_session()

    # Obtener información del usuario
    user_info = session.get('https://www.googleapis.com/userinfo/v2/me').json()
    nombre = user_info.get('name', 'Usuario Google')
    email = user_info.get('email', '')

    return nombre, email

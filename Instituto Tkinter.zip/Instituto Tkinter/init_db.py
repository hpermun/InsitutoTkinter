# init_db.py
from db import Database

if __name__ == '__main__':
    db = Database('instituto.db')
    print("Base de datos creada con éxito.")
